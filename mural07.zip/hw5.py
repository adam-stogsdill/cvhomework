import cv2
import numpy as np
from orb import perform

# Get first image
icurrent = cv2.imread("mural01.jpg")
image_corners = np.asarray([[153, 120], [382, 69], [306, 504], [24, 479]])

desired_width = (1/0.005) * 1.593
desired_height = (1/0.005) * 2.178

print(desired_width, desired_height)

desired_corners = np.asarray([[0,0], [desired_width, 0], [desired_width, desired_height], [0, desired_height]])

desired_corners[:,0] += 50       # Add x offset
desired_corners[:,1] += 100      # Add y offset

H_current_mosaic, _ = cv2.findHomography(image_corners, desired_corners)

output_width = int(desired_width * 5)
output_height = int(desired_height * 2)

first_mural_warped = cv2.warpPerspective(icurrent, H_current_mosaic, (output_width, output_height))

iprev = icurrent
H_prev_mosaic = H_current_mosaic

mural_0_1_points = np.asarray([[521, 182, 1], [716, 184, 1], [705, 400, 1], [477, 375, 1]])

# Loop through rest of images
for i in range(2, 13):
    if i < 10:
        icurrent = cv2.imread("mural0"+str(i)+".jpg")
    else:
        icurrent = cv2.imread("mural"+str(i)+".jpg")

    H_current_mosaic = H_prev_mosaic @ perform("mural01.jpg", "mural0"+str(i)+".jpg", points=mural_0_1_points)

    current_mural_warped = cv2.warpPerspective(icurrent, H_current_mosaic, (output_width, output_height))

    cv2.imshow("ah2", current_mural_warped)
    cv2.waitKey(0)


    
    

#cv2.imshow("ah", bgr_ortho)
#cv2.waitKey(0)